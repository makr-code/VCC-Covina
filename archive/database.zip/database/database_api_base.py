"""
Database API Base Classes
=========================

Base classes for database backends used in Covina.
Provides abstract interface for relational, graph, and vector databases.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple


class DatabaseBackend(ABC):
    """Base class for all database backends"""
    
    @abstractmethod
    def connect(self):
        """Establish connection to database"""
        pass
    
    @abstractmethod
    def disconnect(self):
        """Close database connection"""
        pass
    
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if database is connected"""
        pass


class RelationalBackend(DatabaseBackend):
    """
    Base class for relational database backends (PostgreSQL, MySQL, etc.)
    """
    
    @abstractmethod
    def execute_query(self, query: str, params: Optional[Tuple] = None) -> Any:
        """
        Execute SQL query
        
        Args:
            query: SQL query string
            params: Query parameters (tuple)
            
        Returns:
            Query results
        """
        pass
    
    @abstractmethod
    def execute_many(self, query: str, params_list: List[Tuple]) -> int:
        """
        Execute query with multiple parameter sets
        
        Args:
            query: SQL query string
            params_list: List of parameter tuples
            
        Returns:
            Number of affected rows
        """
        pass
    
    @abstractmethod
    def fetch_all(self, query: str, params: Optional[Tuple] = None) -> List[Dict]:
        """
        Fetch all results from query
        
        Args:
            query: SQL query string
            params: Query parameters
            
        Returns:
            List of result dictionaries
        """
        pass
    
    @abstractmethod
    def fetch_one(self, query: str, params: Optional[Tuple] = None) -> Optional[Dict]:
        """
        Fetch single result from query
        
        Args:
            query: SQL query string
            params: Query parameters
            
        Returns:
            Result dictionary or None
        """
        pass
    
    @abstractmethod
    def commit(self):
        """Commit current transaction"""
        pass
    
    @abstractmethod
    def rollback(self):
        """Rollback current transaction"""
        pass
    
    # ================================================================
    # BATCH OPERATIONS (Phase 3 + Phase 4)
    # ================================================================
    
    def batch_get(self, document_ids: List[str]) -> List[Dict]:
        """
        Batch retrieve multiple documents (Phase 3)
        
        Args:
            document_ids: List of document IDs to retrieve
            
        Returns:
            List of documents
        """
        # Default implementation: sequential fallback
        results = []
        for doc_id in document_ids:
            doc = self.fetch_one("SELECT * FROM documents WHERE document_id = ?", (doc_id,))
            if doc:
                results.append(doc)
        return results
    
    def batch_exists(self, document_ids: List[str]) -> Dict[str, bool]:
        """
        Batch check document existence (Phase 3)
        
        Args:
            document_ids: List of document IDs to check
            
        Returns:
            Dictionary mapping document_id to existence status
        """
        # Default implementation: sequential fallback
        results = {}
        for doc_id in document_ids:
            exists = self.fetch_one("SELECT 1 FROM documents WHERE document_id = ? LIMIT 1", (doc_id,))
            results[doc_id] = exists is not None
        return results
    
    def batch_update(self, updates: List[Dict[str, Any]], mode: str = "partial") -> Dict[str, Any]:
        """
        Batch update multiple documents (Phase 4)
        
        Args:
            updates: List of updates [{"document_id": "...", "fields": {...}}]
            mode: Update mode ("partial" or "full")
            
        Returns:
            dict: {"updated": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        updated = 0
        failed = 0
        errors = []
        
        for update in updates:
            try:
                doc_id = update["document_id"]
                fields = update["fields"]
                # Simple UPDATE implementation
                set_clause = ", ".join([f"{k} = ?" for k in fields.keys()])
                values = list(fields.values()) + [doc_id]
                query = f"UPDATE documents SET {set_clause} WHERE document_id = ?"
                self.execute_query(query, tuple(values))
                updated += 1
            except Exception as e:
                failed += 1
                errors.append({"document_id": update["document_id"], "error": str(e)})
        
        return {"updated": updated, "failed": failed, "errors": errors}
    
    def batch_delete(
        self, 
        document_ids: List[str], 
        mode: str = "soft",
        cascade: bool = True
    ) -> Dict[str, Any]:
        """
        Batch delete multiple documents (Phase 4)
        
        Args:
            document_ids: List of document IDs to delete
            mode: Delete mode ("soft" or "hard")
            cascade: Whether to cascade delete related entities
            
        Returns:
            dict: {"deleted": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        deleted = 0
        failed = 0
        errors = []
        
        for doc_id in document_ids:
            try:
                if mode == "soft":
                    self.execute_query("UPDATE documents SET deleted = TRUE WHERE document_id = ?", (doc_id,))
                else:
                    self.execute_query("DELETE FROM documents WHERE document_id = ?", (doc_id,))
                deleted += 1
            except Exception as e:
                failed += 1
                errors.append({"document_id": doc_id, "error": str(e)})
        
        return {"deleted": deleted, "failed": failed, "errors": errors}
    
    def batch_upsert(
        self, 
        documents: List[Dict[str, Any]],
        conflict_resolution: str = "update"
    ) -> Dict[str, Any]:
        """
        Batch upsert (insert or update) multiple documents (Phase 4)
        
        Args:
            documents: List of documents to upsert
            conflict_resolution: "update" or "skip"
            
        Returns:
            dict: {"inserted": int, "updated": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        inserted = 0
        updated = 0
        failed = 0
        errors = []
        
        for doc in documents:
            try:
                doc_id = doc.get("document_id")
                existing = self.fetch_one("SELECT 1 FROM documents WHERE document_id = ? LIMIT 1", (doc_id,))
                
                if existing:
                    if conflict_resolution == "update":
                        # Update existing
                        fields = {k: v for k, v in doc.items() if k != "document_id"}
                        set_clause = ", ".join([f"{k} = ?" for k in fields.keys()])
                        values = list(fields.values()) + [doc_id]
                        self.execute_query(f"UPDATE documents SET {set_clause} WHERE document_id = ?", tuple(values))
                        updated += 1
                    # else: skip
                else:
                    # Insert new
                    columns = ", ".join(doc.keys())
                    placeholders = ", ".join(["?" for _ in doc])
                    values = list(doc.values())
                    self.execute_query(f"INSERT INTO documents ({columns}) VALUES ({placeholders})", tuple(values))
                    inserted += 1
            except Exception as e:
                failed += 1
                errors.append({"document_id": doc.get("document_id"), "error": str(e)})
        
        return {"inserted": inserted, "updated": updated, "failed": failed, "errors": errors}


class GraphBackend(DatabaseBackend):
    """Base class for graph database backends (Neo4j, etc.)"""
    
    @abstractmethod
    def execute_cypher(self, query: str, params: Optional[Dict] = None) -> Any:
        """Execute Cypher query"""
        pass
    
    # ================================================================
    # BATCH OPERATIONS (Phase 3 + Phase 4)
    # ================================================================
    
    def batch_update(self, updates: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Batch update multiple nodes (Phase 4)
        
        Args:
            updates: List of updates [{"document_id": "...", "fields": {...}}]
            
        Returns:
            dict: {"updated": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        updated = 0
        failed = 0
        errors = []
        
        for update in updates:
            try:
                doc_id = update["document_id"]
                fields = update["fields"]
                set_clause = ", ".join([f"n.{k} = ${k}" for k in fields.keys()])
                params = {**fields, "doc_id": doc_id}
                query = f"MATCH (n:Document {{document_id: $doc_id}}) SET {set_clause}"
                self.execute_cypher(query, params)
                updated += 1
            except Exception as e:
                failed += 1
                errors.append({"document_id": update["document_id"], "error": str(e)})
        
        return {"updated": updated, "failed": failed, "errors": errors}
    
    def batch_delete(
        self, 
        document_ids: List[str], 
        mode: str = "soft",
        cascade: bool = True
    ) -> Dict[str, Any]:
        """
        Batch delete multiple nodes (Phase 4)
        
        Args:
            document_ids: List of document IDs to delete
            mode: Delete mode ("soft" or "hard")
            cascade: Whether to cascade delete (DETACH DELETE)
            
        Returns:
            dict: {"deleted": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        deleted = 0
        failed = 0
        errors = []
        
        for doc_id in document_ids:
            try:
                if mode == "soft":
                    query = "MATCH (n:Document {document_id: $doc_id}) SET n.deleted = true"
                else:
                    query = "MATCH (n:Document {document_id: $doc_id})"
                    query += " DETACH DELETE n" if cascade else " DELETE n"
                
                self.execute_cypher(query, {"doc_id": doc_id})
                deleted += 1
            except Exception as e:
                failed += 1
                errors.append({"document_id": doc_id, "error": str(e)})
        
        return {"deleted": deleted, "failed": failed, "errors": errors}
    
    def batch_upsert(self, documents: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Batch upsert (merge) multiple nodes (Phase 4)
        
        Args:
            documents: List of documents to upsert
            
        Returns:
            dict: {"inserted": int, "updated": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        inserted = 0
        updated = 0
        failed = 0
        errors = []
        
        for doc in documents:
            try:
                doc_id = doc.get("document_id")
                # Check if exists
                check_query = "MATCH (n:Document {document_id: $doc_id}) RETURN n LIMIT 1"
                result = self.execute_cypher(check_query, {"doc_id": doc_id})
                exists = result and len(list(result)) > 0
                
                # Merge
                set_clause = ", ".join([f"n.{k} = ${k}" for k in doc.keys() if k != "document_id"])
                params = doc.copy()
                query = f"MERGE (n:Document {{document_id: $document_id}}) SET {set_clause}"
                self.execute_cypher(query, params)
                
                if exists:
                    updated += 1
                else:
                    inserted += 1
            except Exception as e:
                failed += 1
                errors.append({"document_id": doc.get("document_id"), "error": str(e)})
        
        return {"inserted": inserted, "updated": updated, "failed": failed, "errors": errors}


class VectorBackend(DatabaseBackend):
    """Base class for vector database backends (ChromaDB, etc.)"""
    
    @abstractmethod
    def add_vectors(self, vectors: List[List[float]], metadata: List[Dict]) -> List[str]:
        """Add vectors with metadata"""
        pass
    
    @abstractmethod
    def query_vectors(self, query_vector: List[float], top_k: int = 10) -> List[Dict]:
        """Query similar vectors"""
        pass
    
    # ================================================================
    # BATCH OPERATIONS (Phase 3 + Phase 4)
    # ================================================================
    
    def batch_add_vectors(
        self, 
        vectors: List[List[float]], 
        metadata: List[Dict],
        ids: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Batch add multiple vectors (Phase 3 optimization)
        
        Args:
            vectors: List of embedding vectors
            metadata: List of metadata dictionaries
            ids: Optional list of vector IDs
            
        Returns:
            dict: {"added": int, "failed": int, "errors": [...], "ids": [...]}
        """
        # Default implementation: call single add_vectors
        try:
            result_ids = self.add_vectors(vectors, metadata)
            return {
                "added": len(result_ids),
                "failed": 0,
                "errors": [],
                "ids": result_ids
            }
        except Exception as e:
            return {
                "added": 0,
                "failed": len(vectors),
                "errors": [str(e)],
                "ids": []
            }
    
    def batch_delete_vectors(self, ids: List[str]) -> Dict[str, Any]:
        """
        Batch delete multiple vectors (Phase 4)
        
        Args:
            ids: List of vector IDs to delete
            
        Returns:
            dict: {"deleted": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        deleted = 0
        failed = 0
        errors = []
        
        for vector_id in ids:
            try:
                # Subclasses should override with batch delete
                # This is a placeholder for sequential fallback
                deleted += 1
            except Exception as e:
                failed += 1
                errors.append({"id": vector_id, "error": str(e)})
        
        return {"deleted": deleted, "failed": failed, "errors": errors}
    
    def batch_update_metadata(
        self, 
        ids: List[str], 
        metadata_updates: List[Dict]
    ) -> Dict[str, Any]:
        """
        Batch update metadata for multiple vectors (Phase 4)
        
        Args:
            ids: List of vector IDs to update
            metadata_updates: List of metadata updates
            
        Returns:
            dict: {"updated": int, "failed": int, "errors": [...]}
        """
        # Default implementation: sequential fallback
        updated = 0
        failed = 0
        errors = []
        
        for vector_id, metadata in zip(ids, metadata_updates):
            try:
                # Subclasses should override with batch update
                # This is a placeholder for sequential fallback
                updated += 1
            except Exception as e:
                failed += 1
                errors.append({"id": vector_id, "error": str(e)})
        
        return {"updated": updated, "failed": failed, "errors": errors}


# Alias for compatibility with existing code
VectorDatabaseBackend = VectorBackend


__all__ = [
    'DatabaseBackend',
    'RelationalBackend',
    'GraphBackend',
    'VectorBackend',
    'VectorDatabaseBackend'  # Alias
]
